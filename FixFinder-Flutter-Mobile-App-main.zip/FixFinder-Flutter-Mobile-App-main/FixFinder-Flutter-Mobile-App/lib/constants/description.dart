


const String description = "Welcome to Local service provider- Connecting You with Trusted Local Services Ready to experience hassle-free service at your doorstep? Register now with FixFinder and gain access to a network of skilled professionals for all your household needs.";