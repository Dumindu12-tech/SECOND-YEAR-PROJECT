class Onbording {
  final String title;
  final String imagePathe;
  final String appDescription;

  Onbording(
      {required this.title,
      required this.imagePathe,
      required this.appDescription});
}
