package com.example.checkfirebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
